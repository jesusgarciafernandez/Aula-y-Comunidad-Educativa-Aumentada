# Licencia Profesional de Uso · Sin derecho de reventa ni redistribución

Sistema: Aula y Comunidad Educativa Aumentada · complemento 1.3.4  
Titular: Jesús García Fernández · fecha: 20 de octubre de 2026

Este archivo es la fuente canónica de la licencia de este complemento. Los documentos internos remiten a él.

## 1. Usos permitidos

Puedes utilizar el sistema en tu actividad educativa o profesional y en la de la entidad para la que lo hayas adquirido o recibido legítimamente.

Puedes prestar servicios a empresas, centros, familias y otros clientes con ayuda del sistema; adaptar internamente su configuración y sus instrucciones; y entregar o difundir los resultados profesionales que hayas creado y revisado.

Puedes instalarlo en las plataformas de IA que utilices con tus cuentas y permisos. El paquete no incluye una cuenta ni créditos de ninguna plataforma.

## 2. Archivos internos y resultados

Los resultados profesionales entregables incluyen actividades, explicaciones, guías, feedback, rúbricas, materiales, propuestas, informes, acuerdos y comunicaciones creados mediante el uso del sistema y revisados por una persona responsable. Puedes entregarlos a tus clientes y utilizarlos en tu actividad profesional.

Los archivos internos incluyen instrucciones, agentes, workflows, skills, plantillas fuente, configuraciones, documentación interna, manifiestos, adaptadores y recursos del complemento. La adaptación de un archivo interno no lo convierte en un resultado redistribuible.

## 3. Usos no autorizados

No puedes vender, revender, sublicenciar, alquilar, ceder ni transferir el sistema o sus archivos internos.

No puedes compartir, publicar, entregar a clientes ni redistribuir esos componentes en repositorios, webs, cursos, comunidades, membresías, bibliotecas, plataformas de descarga u otros productos.

No puedes distribuir versiones modificadas o traducidas, compartir copias o accesos para eludir una licencia independiente, presentar el sistema como propio ni retirar la atribución.

Esta limitación se refiere a los componentes internos. No impide prestar servicios profesionales ni entregar los resultados revisados de tu trabajo.

Cualquier permiso adicional de distribución requiere autorización expresa y escrita del titular.

## 4. Supervisión y límites educativos

La persona usuaria y su entidad revisan los resultados y asumen las decisiones educativas y profesionales. El sistema no sustituye al profesorado, orientación, protección del menor, asesoría jurídica ni procedimientos institucionales.

No utilizar el sistema para calificar o clasificar personas, diagnosticar, vigilar exámenes, sancionar ni decidir admisiones, promociones o itinerarios. El uso debe respetar las reglas de privacidad y los límites operativos del sistema.

## 5. Plataformas, privacidad y fuentes

El funcionamiento depende del modelo, las capacidades y los permisos de la plataforma elegida. Debes respetar sus condiciones, privacidad, restricciones de edad y reglas de uso. No se garantiza compatibilidad permanente con ninguna plataforma.

El complemento no incorpora servidor, conectores, registro de usuarios ni telemetría propios de JGF. El proveedor de IA procesa los datos conforme a sus propias condiciones y a la configuración de la cuenta. Instalar el complemento no concede acceso automático a documentación de un centro.

Las fuentes de terceros conservan sus derechos y condiciones. Antes de reutilizar material ajeno, comprueba sus permisos.

## 6. Vigencia y actualizaciones

La fecha de corte normativa de la base documental es el 3 de septiembre de 2026. La adaptación del complemento no acredita que se hayan actualizado las normas citadas.

Comprueba las fuentes oficiales antes de utilizar una referencia normativa con consecuencias. Pasados seis meses desde la fecha de corte, revisa su posible desactualización; pasado un año, comprueba si existe una versión más reciente.

No se garantiza mantenimiento, soporte, actualizaciones ni continuidad. La antigüedad del sistema no extingue por sí sola el permiso de uso ni los derechos sobre tus resultados profesionales.

## 7. Responsabilidad y ausencia de garantías

El sistema se entrega tal cual. No se garantiza ausencia de errores, exactitud de las salidas, cumplimiento normativo de una entidad, mejora de calificaciones ni resultados de aprendizaje. La responsabilidad de revisar el uso, las fuentes y las decisiones corresponde a la persona usuaria y a su entidad.

## 8. Información oficial

- [Campus JGF](https://campus.jesusgarciafernandez.com).
- [Aviso legal y condiciones de uso](https://campus.jesusgarciafernandez.com/aviso-legal-y-condiciones-de-uso/).
- [Política de privacidad](https://campus.jesusgarciafernandez.com/politica-privacidad/).

La política enlazada informa sobre los tratamientos descritos en el Campus. Las condiciones del proveedor de IA rigen el procesamiento realizado por ese proveedor. No se declara certificación de cumplimiento.

Sistema desarrollado por Jesús García Fernández, consultor de innovación e inteligencia artificial aplicada a empresas, negocios y profesionales, con las personas en el centro.
