# Aula y Comunidad Educativa Aumentada

Sistema Aumentado con IA · complemento de skills para Codex · versión 1.3.4.
Desarrollado por Jesús García Fernández.

Prepara actividades, adapta explicaciones, revisa trabajos con feedback formativo y organiza la tutoría y la comunicación con familias. Puedes empezar por una tarea concreta y completar el contexto después.

## Para quién

Docentes, tutoría, orientación, dirección, familias y asociaciones de la comunidad educativa. El alumnado trabaja acompañado. El ámbito de referencia documental es España.

## Qué incluye

Una skill principal de acceso por lenguaje natural, una biblioteca interna de 31 procedimientos especializados, 22 roles de agente, 32 workflows y 58 plantillas en Markdown. La plantilla 17 incluye también una hoja Excel. Los agentes son roles definidos en documentos; su presencia no implica procesos autónomos ni subagentes ejecutándose.

Incluye ejemplos ficticios, referencias educativas y documentación. No incorpora conectores, servidor MCP, autenticación, telemetría ni servicio remoto propio de JGF.

## Primer uso

El ZIP es el paquete del complemento, pero el CLI actual de Codex no lo importa directamente: necesita que el paquete esté dentro de un marketplace local o autorizado. En una instalación con CLI, descomprime el ZIP, crea un catálogo local con un `.agents/plugins/marketplace.json` que apunte a la carpeta `aula-comunidad-educativa-aumentada` y ejecuta `codex plugin marketplace add RUTA_DEL_CATALOGO`; después instala con `codex plugin add aula-comunidad-educativa-aumentada@NOMBRE_DEL_CATALOGO`. El nombre exacto del catálogo y las opciones pueden variar según la versión de Codex. No copies el contenido directamente a una carpeta de skills si quieres que aparezca como complemento.

En el entorno JGF validado, el catálogo se llama `jgf-aula-local` y el flujo completo es:

```text
codex plugin marketplace add RUTA/1.3.4
codex plugin add aula-comunidad-educativa-aumentada@jgf-aula-local
codex plugin list
```

Debe aparecer con `installed: true`, `enabled: true` y la versión esperada. La documentación oficial de plugins describe este modelo de marketplace local y el comando `plugin add`.

Abre una conversación nueva con el complemento disponible y escribe:

> Prepara una actividad de 45 minutos para 2.º de ESO sobre comprobar respuestas de IA, con alternativa sin IA.

También puedes pedir feedback de un trabajo anonimizado o una reunión con familias. La configuración del centro no es requisito para obtener un primer borrador útil.

Si el entorno solo admite skills locales, la carpeta instalable es [skills/aula-comunidad-educativa-aumentada](skills/aula-comunidad-educativa-aumentada/SKILL.md). Esta alternativa carga la skill, pero no crea la ficha de complemento.

## Documentos y resultados

Usa un proyecto dedicado a una sola comunidad educativa. Adjunta únicamente los documentos necesarios o permite el acceso a su carpeta de trabajo. La configuración, el índice de fuentes y los resultados se guardan allí, si la sesión lo permite. El paquete instalado se conserva como biblioteca de lectura.

No incorpores datos identificables de menores. El sistema declara los archivos que ha leído, las consultas realizadas y qué ha podido guardar. Sin acceso de escritura, entrega contenido copiable.

## Criterio humano

El sistema devuelve propuestas y feedback. No califica personas, clasifica alumnado, diagnostica, autentica representación legal ni toma decisiones de admisión, promoción o disciplina. Los materiales y decisiones requieren revisión de la persona responsable.

## Documentación y condiciones

- [Sistema y permisos](SISTEMA.md).
- [Operación y comprobaciones](OPERACION.md).
- [Licencia profesional](LICENSE.md): permite uso profesional y entrega de resultados revisados; prohíbe redistribuir los archivos internos.
- [Página de Aula](https://jesusgarciafernandez.com/ia-para-docentes/).
- [Campus JGF](https://campus.jesusgarciafernandez.com).
- [Aviso legal y condiciones de uso](https://campus.jesusgarciafernandez.com/aviso-legal-y-condiciones-de-uso/).
- [Política de privacidad](https://campus.jesusgarciafernandez.com/politica-privacidad/).

La versión 1.3.4 actualiza los metadatos públicos del complemento y conserva el núcleo adaptado en 1.3.3. No cambia la fecha de corte de sus referencias normativas: 3 de septiembre de 2026. La fecha de empaquetado no acredita una revisión de vigencia normativa.

