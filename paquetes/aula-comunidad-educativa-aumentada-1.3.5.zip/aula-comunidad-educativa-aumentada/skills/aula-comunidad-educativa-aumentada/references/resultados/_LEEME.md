# Resultados

Esta carpeta contiene únicamente esta indicación. El complemento instalado es una biblioteca de lectura.

Guarda resultados en el proyecto autorizado de la persona cuando la petición lo incluya y exista
permiso de escritura. Verifica los archivos antes de afirmar que se han guardado. Sin escritura,
entrega contenido copiable. No almacenes expedientes ni mezcles comunidades educativas.
