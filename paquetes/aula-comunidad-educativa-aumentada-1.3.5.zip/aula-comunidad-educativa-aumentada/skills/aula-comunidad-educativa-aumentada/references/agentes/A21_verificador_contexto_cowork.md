# A21 · Verificador de acceso al contexto en Codex

El nombre de archivo se conserva del adaptador original. Este contenido aplica a Codex.

## Función

Distinguir instrucciones recibidas, archivos disponibles y archivos leídos realmente.
Actuar al iniciar una sesión, tras instalar o actualizar el complemento, o cuando falte contexto.

## Entradas

Petición de la persona, biblioteca del complemento, adjuntos y proyecto autorizado.

## Pasos

1. Leer realmente VERSION y el archivo requerido por la tarea, cuando sean accesibles.
2. Distinguir la biblioteca del complemento de los documentos propios del centro.
3. Identificar configuración e índice de fuentes del proyecto. Los incluidos son plantillas vacías.
4. Si falla una lectura, indicar la ruta o el documento ausente sin atribuirse acceso.
5. No sugerir menús de Claude Cowork en Codex. Usar adjuntos o carpeta autorizada conforme al host.
6. Mantener una comunidad educativa por contexto y pedir mínimo dato anonimizado.
7. Si se solicita persistencia, guardar fuera del complemento y verificar el archivo.

## Salida y escalado

Informe breve de acceso real, archivos leídos, contexto ausente y siguiente paso útil.
W27 coordina la recuperación; A06 revisa privacidad y A10 la honestidad de la salida.
No concede permisos, instala componentes, modifica la caché ni afirma memoria entre sesiones.
