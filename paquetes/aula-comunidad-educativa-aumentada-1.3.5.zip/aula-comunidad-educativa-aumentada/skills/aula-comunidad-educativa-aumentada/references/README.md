# Aula y Comunidad Educativa Aumentada

Sistema Aumentado con IA · complemento Codex 1.3.3 · ámbito de referencia: España.
Titular: Jesús García Fernández.

La entrada del complemento es [README](../../../README.md). El núcleo educativo vive en
[instruccion_maestra.md](instruccion_maestra.md); las rutas cortas de la biblioteca se resuelven desde esta carpeta.

## Contenido

- 22 roles especializados en [agentes](agentes/_LEEME.md).
- 32 procesos en [workflows](workflows/_LEEME.md).
- 31 procedimientos internos en [skills](skills/_LEEME.md).
- 58 plantillas en Markdown y una hoja Excel en [plantillas](plantillas/_LEEME.md).
- [Demostraciones ficticias](demo/README_DEMOSTRACIONES.md).
- [Guía de uso](documentacion/GUIA_MAESTRA_DE_USO.md), privacidad, límites, FAQ y referencias.

La skill principal registra el acceso al sistema; esta biblioteca no instala cada procedimiento como skill independiente.

## Uso

Puedes empezar con una actividad, una explicación, feedback sin nota o una reunión con familias.
Resuelve primero un borrador útil. La configuración del centro se completa después si aporta valor.

La ficha de configuración y el índice de conocimiento son plantillas vacías. Los documentos reales
proceden del proyecto autorizado de la persona. Guarda los resultados allí, nunca dentro del plugin.

A21 y W27 comprueban el acceso en Codex. Conservan nombres de archivo heredados por trazabilidad.

## Fuentes y decisiones

La fecha de corte normativa de la base es 2026-09-03. La adaptación de 2026-10-20 no acredita una
nueva revisión de vigencia. Usa fuentes oficiales contrastadas y deja las decisiones a las personas
responsables.

No pone notas, clasifica alumnado, diagnostica ni decide admisiones, promociones o sanciones.
No cuenta con conectores ni envía comunicaciones por sí mismo.

## Condiciones

[Licencia canónica](../../../LICENSE.md). Permite uso profesional y entrega de resultados revisados;
prohíbe redistribuir archivos internos.

[Campus JGF](https://campus.jesusgarciafernandez.com) ·
[Aviso legal y condiciones](https://campus.jesusgarciafernandez.com/aviso-legal-y-condiciones-de-uso/) ·
[Privacidad](https://campus.jesusgarciafernandez.com/politica-privacidad/).
