# W10 · Revisar el sistema

## Activación

Cuando el titular o el responsable autorizado solicita revisar o actualizar este complemento.

## Entradas y responsable

Versión fuente, cambios solicitados, evidencia de incidencias y fuentes oficiales.
A01 coordina, A09 contrasta las fuentes y A10 comprueba el resultado.

## Pasos

1. Precisar qué cambio se ha autorizado; una revisión no autoriza publicar.
2. Leer el paquete fuente y el changelog; trabajar fuera de la caché instalada.
3. Contrastar las referencias afectadas y registrar fecha y alcance de la consulta.
4. Aplicar cambios mínimos, preservar límites y actualizar versión y changelog.
5. Mantener sincronizados el manifiesto portable y la capa de compatibilidad.
6. Validar estructura, metadatos, referencias y las pruebas de aceptación de OPERACION.md en la raíz.
7. Regenerar e inspeccionar el ZIP si se ha autorizado empaquetar.
8. Instalar, subir, compartir o publicar solo cuando corresponda al encargo explícito.

## Salida

Cambios trazables, versión, pruebas observadas, huecos y siguiente acción.
Si falta una fuente o no se ha ejecutado una prueba necesaria, no declarar el comportamiento verificado.
