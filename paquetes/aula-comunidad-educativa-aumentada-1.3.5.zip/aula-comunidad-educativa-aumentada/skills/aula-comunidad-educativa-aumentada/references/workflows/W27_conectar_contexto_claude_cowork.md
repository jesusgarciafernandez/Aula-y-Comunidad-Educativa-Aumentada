# W27 · Comprobar contexto en Codex

Nombre de archivo heredado. Adaptación 1.3.3 para Codex.

## Activación y entradas

Al iniciar el complemento, actualizarlo, fallar una lectura o depender de documentación del centro.
Entradas: tarea, biblioteca disponible, proyecto autorizado y adjuntos.

## Responsable

A21, con A06 para privacidad y A10 antes de entregar.

## Proceso

1. Identificar qué archivos de biblioteca requiere la tarea y leerlos.
2. Comprobar el contexto autorizado del proyecto y los documentos aportados.
3. Localizar configuración e índice reales; no confundir las plantillas incluidas con datos del centro.
4. Informar de archivos ausentes sin inventar contenido ni lecturas.
5. Con contexto parcial, resolver lo posible y marcar huecos como «No consta».
6. Si se solicita guardar, usar el workspace autorizado, separado de la biblioteca del plugin.
7. Verificar el guardado y devolver una ruta real o contenido copiable.

## Salida y errores

Lista breve de lecturas reales y contexto disponible. La falta de acceso a un documento bloquea
solo lo que depende de él. Si no se puede leer el núcleo, no afirmar que el sistema completo está activo.

No instalar herramientas ni cambiar permisos por este workflow. No escribir datos del centro en la
caché del complemento ni aplicar pasos de instalación de otra plataforma.
