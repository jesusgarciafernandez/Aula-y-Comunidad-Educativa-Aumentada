# Acceso al contexto · adaptación Codex

Este nombre de archivo se conserva por trazabilidad. Para este complemento, seguir
[W27](../workflows/W27_conectar_contexto_claude_cowork.md) y
[A21](../agentes/A21_verificador_contexto_cowork.md), adaptados a Codex.

Instalar el complemento y autorizar archivos del centro son acciones distintas. La lectura debe
comprobarse en la sesión. Los documentos y resultados permanecen en el proyecto de la persona.
No se utilizan en Codex los pasos de instalación de Claude Cowork del paquete original.
