# Guía Maestra de Uso

## Sistema Aumentado de Aula y Comunidad Educativa · versión 1.3.3

**Fecha de corte operativa:** 2026-09-04  
**Origen y acceso:** [Campus JGF](https://campus.jesusgarciafernandez.com) · Jesús García Fernández.  
**Público principal:** dirección de institutos, docentes de Educación Secundaria, padres/madres y tutores legales de alumnado de esta etapa.  
**Ámbito:** España, con carril de contraste para las 17 comunidades autónomas y la gestión ministerial de Ceuta y Melilla.  
**Naturaleza:** guía de uso y supervisión; no es dictamen jurídico ni sustituye al centro, al profesorado, a orientación, al DPD o a la asesoría competente.

> **Regla de lectura:** el sistema propone, explica, estructura y deja trazabilidad. Las personas autorizadas revisan, deciden, aprueban y ejecutan. Toda consecuencia territorial o normativa se expresa como **Sugerencia operativa a revisar y contrastar**.

## Índice

1. [Qué es este sistema aumentado](#1-qué-es-este-sistema-aumentado)
2. [Objetivos y usos](#2-objetivos-y-usos)
3. [Marco actual](#3-marco-actual)
4. [Sugerencias de uso por perfil](#4-sugerencias-de-uso-por-perfil)
5. [Cómo instalarlo y empezar](#5-cómo-instalarlo-y-empezar)
6. [Cómo elegir el modo de trabajo](#6-cómo-elegir-el-modo-de-trabajo)
7. [Mapa de rutas](#7-mapa-de-rutas)
8. [Carril de familias y tutores](#8-carril-de-familias-y-tutores)
   - [Inicio de curso y apoyo a la comunidad](#86-inicio-de-curso-y-apoyo-a-la-comunidad)
9. [Carril autonómico y fuentes oficiales](#9-carril-autonómico-y-fuentes-oficiales)
10. [Contrato de salida y trazabilidad](#10-contrato-de-salida-y-trazabilidad)
11. [Privacidad, menores y situaciones sensibles](#11-privacidad-menores-y-situaciones-sensibles)
12. [Prompts de inicio](#12-prompts-de-inicio)
13. [Demostraciones](#13-demostraciones)
14. [Revisión humana y ciclo de vida](#14-revisión-humana-y-ciclo-de-vida)
15. [Mapa documental y soporte](#15-mapa-documental-y-soporte)

## 1. Qué es este sistema aumentado

Este proyecto es un **Sistema Aumentado con IA para Aula y Comunidad Educativa**, desarrollado por
Jesús García Fernández y distribuido desde el [Campus JGF](https://campus.jesusgarciafernandez.com).
El Campus es el punto de acceso y aprendizaje; el sistema es el conjunto portable que se instala o
abre sobre la herramienta de IA que el centro o la persona elija.

Convierte una IA generalista en un ayudante educativo con contexto, agentes, skills, workflows,
plantillas, fuentes y controles. No ofrece una “caja negra” que decide por el instituto: sugiere organización del
trabajo para que dirección, docentes, familias y tutores puedan comprenderlo, revisarlo y adaptarlo.

Está pensado para cuatro perspectivas conectadas:

| Perfil | Qué encuentra aquí |
|---|---|
| Dirección de instituto | Gobernanza, normas de uso, pilotaje, seguimiento, fuentes y decisiones que deben aprobarse |
| Docente de Secundaria | Actividades, programaciones, adaptaciones, feedback y acción tutorial |
| Padre/madre o tutor legal | Información clara, preguntas para el centro, acompañamiento y mediación digital |
| Tutor/a docente y orientación | Entrevistas, acuerdos, transición, bienestar, inclusión y coordinación |

### Qué significa “aumentado”

La IA ayuda a preparar, comparar, ordenar y hacer visibles los siguientes pasos. Las personas aportan
el contexto, el criterio profesional, la relación educativa y la decisión. El sistema debe mantener
esa frontera en cada salida.

No es un LMS, expediente académico, cuaderno de notas, detector fiable de uso de IA, sistema de
vigilancia, servicio de diagnóstico, sustituto del profesorado o asesoría jurídica. No envía
comunicaciones, publica, matricula, califica, sanciona, firma ni decide por una familia, un alumno,
un docente o un órgano del centro.

## 2. Objetivos y usos

### Objetivos

1. **Dar claridad:** reducir el ruido alrededor de la IA y convertir una necesidad educativa en un siguiente paso terminado.
2. **Mejorar el trabajo real:** preparar materiales, tutorías y decisiones con contexto, criterios y evidencias.
3. **Proteger a las personas:** minimizar datos, respetar la voz del alumno y evitar automatismos que puedan perjudicarle.
4. **Fortalecer la autonomía:** que el centro aprenda a revisar, adaptar y gobernar el uso de IA sin depender de una respuesta automática.
5. **Conectar comunidad:** facilitar conversaciones entre dirección, docentes, familias, tutores y orientación.
6. **Trabajar con criterio territorial:** localizar fuentes oficiales de la comunidad aplicable sin presentarlas como certificado.

### Usos principales

- **Dirección:** preparar un piloto, una política de uso, una reunión de equipo, un registro de decisiones o una revisión de riesgos.
- **Docencia:** diseñar actividades, situaciones de aprendizaje y programaciones; adaptar explicaciones; preparar feedback formativo sin calificación.
- **Tutoría:** organizar entrevistas, hábitos de estudio, acogida, transición, convivencia, bienestar, absentismo y coordinación con orientación.
- **Familias:** comprender opciones, preparar preguntas para el centro, acompañar el aprendizaje en casa y acordar un uso digital responsable.
- **Comunidad educativa:** diseñar consultas accesibles, talleres, normas participativas y canales de retorno.

El sistema no hace la tarea del alumno ni convierte una conversación familiar en un expediente. Produce
borradores y apoyos para que cada responsable pueda revisarlos.

## 3. Marco actual

La Educación Secundaria trabaja en un contexto de cambio tecnológico acelerado: la IA ya puede generar
textos, resumir, comparar y proponer, pero también puede inventar información, amplificar sesgos o
tratar datos de forma inadecuada. Por eso este proyecto se apoya en el principio JGF de
**personas en el centro**: la tecnología potencia el trabajo, pero no sustituye el criterio ni la responsabilidad.

El marco educativo y regulatorio no es idéntico para todo el territorio. Conviven referencias estatales
europeas, currículo e instrucciones autonómicas, normas del centro y decisiones profesionales. La
fecha de corte de esta versión es 2026-09-04; las referencias pueden cambiar y deben comprobarse antes
de aplicarse. El índice `documentacion/REFERENCIAS_NORMATIVAS.md`, el marco familiar y el directorio
autonómico reúnen los enlaces oficiales y el método de contraste.

En este contexto, la guía propone una implantación gradual: empezar por un uso educativo acotado,
observarlo, revisar la experiencia de las personas afectadas y solo después decidir si se amplía. En
normativa, protección de menores, representación, orientación o convivencia, el sistema orienta y
documenta; el centro y sus responsables validan.

## 4. Sugerencias de uso por perfil

### Dirección de instituto

Podría ser conveniente nombrar una persona responsable del piloto, reunir dirección–docencia–tutoría–
orientación–familias, acordar qué información no entra en herramientas externas y empezar con dos o
tres workflows. Antes de extenderlo, revisar resultados, accesibilidad, carga de trabajo, quejas y
la opinión del alumnado.

### Docentes de Secundaria

Puede ser útil comenzar por una actividad, una explicación adaptada o un feedback con rúbrica. Pedir
siempre evidencia, alternativa sin IA y preguntas de comprobación. La calificación y la decisión
pedagógica siguen siendo del docente.

### Padres, madres y tutores legales

Pueden usarlo para preparar preguntas, entender una opción educativa, organizar una rutina breve de
estudio o redactar un acuerdo familiar de pantallas e IA. Deben evitar introducir datos identificativos
o información de otros miembros de la comunidad y confirmar los canales con el centro.

### Tutoría y orientación

Puede ayudar a estructurar entrevistas y acuerdos. Conviene separar hechos de hipótesis, incluir la
voz del alumno, no diagnosticar y activar el protocolo humano cuando aparezca una preocupación de
protección.

### Sugerencia de implantación en cuatro pasos

1. **Entender:** leer esta guía y probar una demostración ficticia.
2. **Acotar:** elegir un uso, un perfil responsable, una fuente y una fecha de revisión.
3. **Pilotar:** trabajar con datos ficticios o minimizados y registrar incidencias.
4. **Decidir:** revisar evidencias y aprobar, modificar, pausar o retirar el uso.

## 5. Instalar el complemento y empezar

### 5.1 Instalación

Este paquete es el complemento Codex 1.3.3. Su raíz contiene el manifiesto portable,
la capa de compatibilidad y la carpeta de skills. En el CLI actual, el ZIP no se importa
directamente: descomprímelo, registra como marketplace la carpeta que contiene
`.agents/plugins/marketplace.json` y ejecuta `codex plugin add` con el identificador del
complemento. Si tu cuenta ofrece una carga de complementos o un marketplace autorizado,
usa ese flujo equivalente.

En el catálogo local JGF:

```text
codex plugin marketplace add RUTA/1.3.3
codex plugin add aula-comunidad-educativa-aumentada@jgf-aula-local
codex plugin list
```

Comprueba que aparece con `installed: true`, `enabled: true` y la versión esperada.

La presencia del ZIP no acredita instalación. Si el host solo permite skills locales, usa la
carpeta de la skill principal como alternativa; ese flujo no crea la ficha de complemento.
Consulta el README de la raíz para las rutas.

### 5.2 Primer resultado

Escribe en lenguaje natural qué necesitas. Por ejemplo:

> Prepara una actividad de 45 minutos para 2.º de ESO sobre cómo comprobar una respuesta de IA.
> Incluye una alternativa sin IA y una comprobación de comprensión.

Puedes empezar sin configurar el centro. El sistema distingue supuestos de datos aportados,
lee el workflow pertinente y devuelve un borrador para revisión.

### 5.3 Contexto y guardado

Usa un proyecto dedicado a una sola comunidad educativa. Aporta documentos anonimizados
o autoriza su carpeta. La ficha y el índice de fuentes del complemento son plantillas vacías.

Si solicitas guardar, el sistema usa el proyecto autorizado y verifica el archivo.
No guarda datos del centro en la biblioteca instalada. Sin escritura, devuelve texto copiable.
A21 y W27 comprueban el acceso real de la sesión en Codex; sus nombres de archivo son heredados.

### 5.4 Comprobar

Pide que enumere únicamente los archivos que ha leído, las consultas que ha realizado y
los resultados que ha guardado. Una respuesta basada en una demo se identifica como ficticia.

La validación de este adaptador se describe en OPERACION.md, en la raíz del complemento.
La prueba de instalación y comportamiento en el host debe registrarse después de ejecutarla.

## 6. Cómo elegir el modo de trabajo

| Necesidad | Modo o ruta principal | Resultado esperado |
|---|---|---|
| Crear una actividad o situación de aprendizaje | Diseño educativo · W02/W03 | Secuencia, evidencia, alternativa sin IA y revisión |
| Explicar o adaptar un contenido | Adaptación · W03 | Versión ajustada y comprobación de comprensión |
| Revisar un trabajo | Feedback formativo · W04 | Evidencias, fortalezas, preguntas y próximos pasos; sin nota |
| Crear normas de IA | Gobernanza · W06/W07 | Borrador participativo, usos permitidos/condicionados/no permitidos |
| Preparar una tutoría | Tutoría · W13/W21 | Guion, hechos/interpretaciones, voz del alumno y acuerdos |
| Incorporar a familias | Familias · W20/W23 | Canales, derechos, responsabilidades y participación accesible |
| Acompañar el aprendizaje en casa | Familias · W22/W24 | Plan breve, responsabilidades distribuidas y revisión |
| Orientar una decisión educativa | Orientación · W25 | Opciones verificadas, preguntas y decisión compartida |
| Consultar una comunidad autónoma | Contraste autonómico · W26 | Fuentes oficiales, huecos y sugerencias a contrastar |
| Situación de riesgo o protección | Bienestar · W13 | Activación del protocolo humano aplicable; no aviso automático |

Si una petición mezcla rutas, el orquestador debe declarar la secuencia y la salida de cada una. Si
no puede determinar el rol o el territorio, debe pedir el dato mínimo o marcarlo como `No consta`,
sin inferirlo por el idioma, el centro o la similitud con otra comunidad.

## 7. Mapa de rutas

El núcleo `instruccion_maestra.md` gobierna la respuesta. La ruta recomendada es:

```text
necesidad → rol/etapa/territorio → agente → workflow → skill → plantilla → revisión humana → registro
```

Los agentes atienden las relaciones con familias y tutores, contrastan el contexto autonómico y
aportan salvaguardas, fuentes, inclusión, bienestar, transición y mediación digital. Los workflows
forman el carril ampliado.

Antes de entregar, comprobar:

- ¿La respuesta está dentro del rol solicitado y no revela datos de otra persona?
- ¿Se distinguen hechos, fuentes, interpretación, propuesta y decisión pendiente?
- ¿Se usa una fuente oficial cuando se habla de normativa o procedimiento?
- ¿La salida dice `No consta` cuando falta el dato?
- ¿Incluye alternativa sin IA cuando la tarea educativa lo necesita?
- ¿Quién debe revisar, aprobar, comunicar o ejecutar está identificado?

## 8. Carril de familias y tutores

### 8.1 Incorporación y representación

Sirve para explicar cómo participar, qué preguntar y qué canal debe confirmar el centro. La
familia aporta su contexto; no se debe pedir más información personal de la necesaria. La identidad,
la representación, la patria potestad, la tutela, la custodia o las restricciones de comunicación
no se presuponen: el centro las verifica por sus canales institucionales.

### 8.2 Entrevistas familia–tutor

Las plantillas organizan una conversación colaborativa. El orden recomendado es:

1. propósito y límites de la reunión;
2. hechos observables y periodo de referencia;
3. fortalezas y contexto aportado por la familia;
4. voz del alumno, según edad y madurez;
5. hipótesis abiertas, nunca etiquetas ni diagnósticos;
6. dos o tres acuerdos con responsable, fecha e indicador;
7. canal de revisión y registro mínimo.

### 8.3 Aprendizaje en el hogar y mediación digital

Ayudan a convertir un conflicto cotidiano en un experimento breve y revisable. El sistema
no hace la tarea del alumno, no prescribe vigilancia total ni sustituye la conversación familiar.
Puede proponer un acuerdo recíproco de pantallas e IA: finalidad, horarios, privacidad, comprobación
de fuentes, ayuda permitida, señales de alerta y fecha de revisión.

### 8.4 Orientación y transición

Compara opciones con información aportada o localizada en fuentes verificables. No predice el
éxito de una persona, no decide itinerario y no reemplaza la orientación del centro. Debe incorporar
la voz del alumno, sus intereses, las condiciones reales de acceso y preguntas para la entrevista
con orientación.

### 8.5 Participación inclusiva

Ofrece más de un canal, horarios razonables, lenguaje claro, apoyos de idioma y acceso,
alternativas no digitales y retorno agregado de lo aprendido. No se publican respuestas individuales
ni se usa una consulta familiar para perfilar a otras familias.

### 8.6 Inicio de curso y apoyo a la comunidad

El sistema incorpora un carril específico para las primeras semanas. No entrega una agenda genérica:
primero identifica público, etapa, calendario, duración, asistentes, canales, idioma, accesibilidad y
decisiones ya aprobadas. Después separa los hitos y prepara materiales que cada grupo pueda utilizar.

| Necesidad | Ruta | Resultado sugerido |
|---|---|---|
| Organizar el curso desde dirección | W28 · `plan_inicio_curso_centro` | Hitos, responsables, materiales y revisión a 2–4 semanas |
| Preparar el primer día con alumnos | W29 · `primer_dia_alumnado` | Guion flexible, pertenencia, orientación, ayuda y alternativa accesible |
| Preparar la primera reunión docente-familia | W30 · `primera_reunion_docente_familia` | Agenda, escucha, voz del alumno y acuerdos revisables |
| Preparar la reunión general del instituto | W31 · `reunion_instituto_familias` | Mensajes comunes, canales, preguntas y apoyos de acceso |
| Ayudar a las familias a empezar | W32 · `apoyo_familias_inicio_curso` | Checklist breve, primer paso, ayuda y revisión a 7–15 días |

En los cinco casos, cada salida debe indicar qué está confirmado, qué es **Propuesta**, qué queda como
`No consta`, quién aprueba y cómo se comprobará la comprensión. La comprobación puede ser localizar un
canal, repetir tres mensajes, explicar el primer paso o elegir una alternativa; no es un examen.

La reunión general no incluye expedientes ni situaciones individuales. La primera reunión docente-familia
no diagnostica ni evalúa la crianza. El apoyo familiar no impone vigilancia total ni sustituye al centro.
Las propuestas son **Sugerencias operativas a revisar y contrastar** y requieren aprobación humana.

## 9. Carril autonómico y fuentes oficiales

Sirven para localizar y contrastar, no para certificar. El documento
`documentacion/FUENTES_AUTONOMICAS_EDUCACION_FAMILIAS_TUTORIA.md` reúne las puertas de entrada
oficiales de Andalucía, Aragón, Asturias, Illes Balears, Canarias, Cantabria, Castilla-La Mancha,
Castilla y León, Cataluña, Comunitat Valenciana, Extremadura, Galicia, Comunidad de Madrid, Región
de Murcia, Comunidad Foral de Navarra, País Vasco, La Rioja, Ceuta y Melilla.

La respuesta autonómica debe contener, como mínimo:

- territorio y etapa, confirmados por el usuario;
- boletín oficial, portal educativo y norma o instrucción localizada;
- URL oficial y fecha de consulta;
- alcance: estatal, autonómico, centro o curso;
- vigencia pendiente de comprobación cuando corresponda;
- huecos documentales y autoridad que debe validar;
- **Sugerencia operativa a revisar y contrastar**.

No se extrapola Madrid a otra comunidad, ni una norma curricular a una decisión familiar concreta,
ni un decreto a un protocolo de centro. El índice `documentacion/REFERENCIAS_NORMATIVAS.md` es el
registro estatal y europeo de referencias; `MARCO_LEGAL_FAMILIAS_Y_TUTORIA.md` explica el carril
familiar. Ambos advierten que las fuentes oficiales deben comprobarse en su texto vigente.

## 10. Contrato de salida y trazabilidad

Una salida útil se presenta en capas:

1. **Resumen para decidir:** qué se propone y qué no se puede concluir.
2. **Evidencias:** datos aportados o fuentes consultadas, con fecha.
3. **Propuesta:** pasos, responsables, recursos y alternativa sin IA cuando aplique.
4. **Huecos:** `No consta`, dato que falta y cómo obtenerlo.
5. **Revisión humana:** quién debe revisar, aprobar o activar un protocolo.
6. **Registro:** agente, workflow, skill, plantilla, versión y fecha.

La `documentacion/MATRIZ_TRAZABILIDAD_SISTEMA.md` conecta requisitos con piezas y demostraciones.
No es una certificación automática: si una fila no tiene evidencia o responsable, queda pendiente.

## 11. Privacidad, menores y situaciones sensibles

Usar datos ficticios o anonimizados en las pruebas. No incorporar nombres completos, DNI/NIE,
correos, teléfonos, diagnósticos, expediente, mensajes privados, imágenes íntimas o identificadores
de menores. No revelar a un progenitor información del otro ni información de terceros.

La IA no determina salud mental, maltrato, acoso, custodia, representación, sanción, promoción,
admisión, calificación o uso de una herramienta por un alumno. Ante una preocupación de protección,
la primera acción es activar el protocolo humano del centro y, si corresponde, los servicios y
autoridades competentes. No se pide material sensible para “analizarlo” ni se envía una comunicación
automática a la familia.

La normativa se consulta como referencia documentada. La aplicación a un caso concreto corresponde
al centro y a sus responsables: DPD, dirección, secretaría, orientación, inspección o asesoría, según
la materia. El sistema no firma ni declara cumplimiento.

## 12. Prompts de inicio

### Familia

> Soy familiar de un alumno de [etapa/curso] en [territorio]. Quiero entender [tema]. No uses datos identificativos. Separa información oficial, dudas y sugerencias operativas a revisar y contrastar. Termina con preguntas para el centro.

### Tutor/a

> Soy tutor/a de [curso]. Prepara [entrevista/plan] con una familia usando un caso ficticio. Separa hechos de hipótesis, incluye fortalezas y voz del alumno, protege la privacidad y termina con acuerdos medibles, responsables y fecha de revisión.

### Contraste autonómico

> El centro está en [comunidad/ciudad autónoma] y la etapa es [etapa]. Activa W26. Localiza solo fuentes oficiales, indica URL y fecha, no extrapoles desde otra comunidad y formula toda consecuencia como “Sugerencia operativa a revisar y contrastar”.

### Revisión de una salida

> Audita esta propuesta con la matriz de trazabilidad. Marca hechos, fuente, inferencia, huecos, responsable de validar y riesgos de privacidad. Si algo no consta, no lo completes por similitud.

## 13. Demostraciones

Las demostraciones son sintéticas y no representan a ningún centro ni familia real:

- `demo/caso_familia_autonomia.md`: familia de 4.º de ESO en Illes Balears que pide fuentes antes de elegir optativas.
- `demo/caso_tutoria_familia.md`: entrevista entre tutoría y familia por hábitos de estudio, con voz del alumno y acuerdos.
- `demo/caso_contraste_autonomico.md`: contraste prudente de un caso situado en la Comunidad de Madrid.
- `demo/caso_inicio_curso.md`: preparación del inicio de curso para centro, alumnado, docentes y familias.
- `demo/README_DEMOSTRACIONES.md`: índice, forma de ejecutar y criterios de observación.

Cada caso contiene petición, enrutamiento, salida esperada, salvaguardas, trazabilidad y checklist de
revisión humana. Las demostraciones no deben copiarse con datos reales sin adaptar el protocolo del
centro.

## 14. Revisión humana y ciclo de vida

Antes de usar una salida en un centro:

1. el docente revisa la calidad pedagógica y la accesibilidad;
2. la tutoría u orientación revisa el acompañamiento y la voz del alumno;
3. dirección, secretaría o el órgano competente revisa canales, representación y decisiones;
4. el DPD o asesoría revisa privacidad y base jurídica cuando corresponda;
5. la persona responsable contrasta las fuentes oficiales y registra fecha, huecos y decisión.

La versión declara una fecha de corte. Pasados seis meses, tratar las referencias normativas como
pendientes de actualización. La entrega no promete mantenimiento futuro: revisar el registro de
decisiones y reconstruir los paquetes si cambia una fuente, un workflow, una skill o una salvaguarda.

## 15. Mapa documental y soporte

| Necesidad | Documento |
|---|---|
| Puerta de entrada | `EMPIEZA_AQUI.md` |
| Configuración mínima | `00_CONFIGURACION_COMUNIDAD_EDUCATIVA.md` |
| Núcleo | `instruccion_maestra.md` |
| Familias y tutoría | `documentacion/MARCO_LEGAL_FAMILIAS_Y_TUTORIA.md` |
| Normativa estatal/europea | `documentacion/REFERENCIAS_NORMATIVAS.md` |
| CCAA, Ceuta y Melilla | `documentacion/FUENTES_AUTONOMICAS_EDUCACION_FAMILIAS_TUTORIA.md` |
| Trazabilidad | `documentacion/MATRIZ_TRAZABILIDAD_SISTEMA.md` |
| Agentes y workflows | `agentes/`, `workflows/` |
| Skills y plantillas | `skills/`, `plantillas/` |
| Pruebas | `tests/PLAN_DE_PRUEBAS.md`, `tests/GUION_PRUEBAS_PLATAFORMA.md` |
| Demostraciones | `demo/README_DEMOSTRACIONES.md` |

**Uso:** borradores educativos revisables; las decisiones corresponden a las personas responsables.
