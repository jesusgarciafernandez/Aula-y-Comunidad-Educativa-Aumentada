# Condiciones de uso · complemento Codex 1.3.3

La fuente canónica de licencia de este complemento es [LICENSE.md](../../../../LICENSE.md).
Permite utilizar el sistema para la actividad profesional y prestar servicios a terceros, así como
entregar los resultados revisados. No permite vender, compartir ni redistribuir sus archivos internos.

[Campus JGF](https://campus.jesusgarciafernandez.com) ·
[Aviso legal y condiciones de uso](https://campus.jesusgarciafernandez.com/aviso-legal-y-condiciones-de-uso/) ·
[Política de privacidad](https://campus.jesusgarciafernandez.com/politica-privacidad/).

La política del Campus cubre los tratamientos que describe. El procesamiento del proveedor de IA se
rige por sus propias condiciones y por la configuración de la cuenta. No se declara cumplimiento
certificado ni se sustituye la responsabilidad de la persona usuaria y su entidad.
