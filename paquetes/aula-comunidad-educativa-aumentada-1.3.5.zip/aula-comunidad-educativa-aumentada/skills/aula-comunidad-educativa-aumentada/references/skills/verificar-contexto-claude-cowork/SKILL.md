---
name: verificar-contexto-claude-cowork
description: "Procedimiento interno de acceso al contexto; nombre heredado, adaptado a Codex mediante A21 y W27."
---

# Verificar acceso al contexto

Procedimiento interno del complemento 1.3.3. Se activa cuando faltan archivos, hay dudas de acceso
o se pide comprobar qué contexto se ha leído.

Leer A21 y W27. Distinguir biblioteca instalada, proyecto autorizado y documentos leídos.
No simular lecturas ni aplicar menús de otra plataforma. No guardar datos del centro en el complemento.
La salida identifica archivos leídos, huecos y siguiente paso de recuperación. A10 valida el resultado.
