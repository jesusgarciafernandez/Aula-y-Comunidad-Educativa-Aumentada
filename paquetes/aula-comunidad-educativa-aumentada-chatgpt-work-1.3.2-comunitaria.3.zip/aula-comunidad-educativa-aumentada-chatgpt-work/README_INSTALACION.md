# Instalación · Aula y Comunidad Educativa Aumentada · Edición Comunitaria

**Paquete:** ChatGPT Work · **Versión:** `1.3.2-comunitaria.3`

## Qué contiene

Una skill llamada `aula-comunidad-educativa-aumentada/`, con:

- `SKILL.md` — punto de entrada descubrible por intención natural.
- `references/` — núcleo, agentes, workflows, skills, conocimiento y documentación.
- `assets/plantillas/` — las cincuenta y nueve plantillas Markdown, incluido `_LEEME.md`, y la matriz Excel.
- `agents/openai.yaml` — nombre visible, descripción y política de invocación.

Además, la raíz contiene `tests/` con el validador estático y fixtures ficticios, `demo/` con casos de
uso sin datos reales, `mantenimiento/` con la arquitectura del sistema, y `LICENSE.md`, `VERSION` y
`CHANGELOG.md`.

## Instalación e inicio

1. Crea o abre un proyecto local para la comunidad educativa.
2. Asocia la carpeta extraída como carpeta de trabajo del proyecto; debe quedar accesible
   `aula-comunidad-educativa-aumentada/SKILL.md` y `aula-comunidad-educativa-aumentada/references/`.
3. Abre una conversación nueva dentro de ese proyecto.
4. Escribe la tarea directamente en lenguaje natural, por ejemplo: *«Prepárame una actividad de 45
   minutos para 2.º de ESO sobre energía»*.

No necesitas escribir comandos ni nombrar componentes internos. Como comprobación inicial opcional,
puedes pedir: *«Indica qué sistema eres, qué versión tienes y qué archivos has leído realmente»*.
Si la sesión no ofrece descubrimiento automático, solicita que lea el `SKILL.md` local y aplique sus
instrucciones; no debe afirmarse una activación runtime que no pueda observarse.

## Documentos de tu centro

El sistema funciona con archivos. Coloca los documentos de tu centro en un **Proyecto dedicado a una
sola comunidad educativa** y adjúntalos a la conversación, o añádelos dentro de
`references/conocimiento/` siguiendo el `_LEEME.md` de cada carpeta. Registra cada documento en
`references/conocimiento/00_INDICE_FUENTES.md`: lo que no esté ahí, el sistema no puede citarlo.

## Guardado de resultados

Comprueba si tu sesión puede escribir archivos. Si no puede, el sistema te dará el contenido para
copiar y te lo dirá. Nunca debe afirmar que ha guardado algo que no ha guardado.

> Esta edición distingue entre archivos accesibles, skill descubierta y ejecución runtime realmente
> observada. Si tu cuenta presenta los menús con otro nombre, conserva esa trazabilidad.

## Inicio rápido en 4 pasos

1. **Crea o abre un proyecto local** para este sistema aumentado.
2. **Asocia la carpeta extraída** como carpeta de trabajo del proyecto.
3. **Abre una conversación nueva** dentro de ese proyecto.
4. **Escribe tu tarea en lenguaje natural**, por ejemplo: «Prepárame una actividad de 45 minutos para 2.º de ESO sobre energía». No necesitas conocer nombres de skills, agentes ni workflows.

Como comprobación inicial, puedes pedir: «Indica qué sistema eres, qué versión tienes y qué archivos has leído realmente». Después, empieza directamente con una tarea docente.

Cuando ya tengas un resultado, ofrece la configuración mínima del centro. No introduzcas datos reales de menores.

El manual completo en PDF se facilita junto con esta edición desde el repositorio oficial.
Documentación de uso: `aula-comunidad-educativa-aumentada/references/documentacion/GUIA_DE_INICIO.md`.
Condiciones comunitarias: `aula-comunidad-educativa-aumentada/references/documentacion/CONDICIONES_DE_USO.md`. Descarga sin compra, cupón ni registro en tienda.

## Límites que conviene conocer antes de empezar

Este sistema no pone notas, no clasifica alumnado, no detecta si un texto lo escribió una IA, no
sanciona, no diagnostica y no envía ni publica nada. Ver `aula-comunidad-educativa-aumentada/references/documentacion/LIMITES_Y_ESCALADO.md`.

> **Versión 1.3.2-comunitaria.3.** La adaptación comunitaria no extiende automáticamente las confirmaciones
> históricas a estos nuevos ZIP. El paquete de mantenimiento distingue comprobaciones estáticas,
> pruebas históricas y pruebas de plataforma pendientes. Ver `aula-comunidad-educativa-aumentada/references/documentacion/EDICION_COMUNITARIA.md`.
