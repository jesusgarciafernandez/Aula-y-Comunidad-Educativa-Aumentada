# Aula y Comunidad Educativa Aumentada · ChatGPT Work

Edición Comunitaria · versión `1.3.2-comunitaria.3` · Jesús García Fernández.

Este paquete contiene una skill de uso local y sus referencias completas. El núcleo se encuentra en
`aula-comunidad-educativa-aumentada/`; las comprobaciones, demostraciones y documentación de mantenimiento están en esta raíz.

## Contenido

- `aula-comunidad-educativa-aumentada/SKILL.md`: punto de entrada de la skill.
- `aula-comunidad-educativa-aumentada/references/`: instrucción maestra, 31 skills, 22 agentes, 32 workflows, documentación y conocimiento.
- `aula-comunidad-educativa-aumentada/assets/plantillas/`: 60 archivos de plantillas y recursos.
- `tests/`: validador estático, plan, registro y fixtures ficticios.
- `demo/`: demostraciones sin datos reales.
- `mantenimiento/`: arquitectura, decisiones y evolución del sistema.
- `LICENSE.md`, `VERSION` y `CHANGELOG.md`: identidad y condiciones de la entrega.

## Uso

Abre la carpeta del paquete dentro del proyecto o sesión de trabajo y formula la tarea en lenguaje
natural. Si la sesión no expone un invocador de skills, solicita que lea `aula-comunidad-educativa-aumentada/SKILL.md` y aplique
solo las referencias necesarias. La lectura de un archivo no se presentará como invocación runtime.

## Comprobación local

Si la sesión permite ejecutar Python, desde esta carpeta ejecuta:

`python3 tests/validador_estructura.py . --tipo chatgpt-work --version 1.3.2-comunitaria.3`

El validador comprueba estructura, versión, integridad, rutas, datos personales, referencias normativas
y cobertura del paquete. No demuestra por sí solo la ejecución conversacional de skills, agentes o workflows.

No introduzcas datos reales de menores. Las decisiones educativas, de protección y de publicación son
humanas y requieren revisión y autorización.
