# Instalación · Aula y Comunidad Educativa Aumentada · Edición Comunitaria

**Paquete:** Genérico · **Versión:** `1.3.2-comunitaria.3`

## Para qué es este paquete

Para cualquier herramienta de IA que pueda leer texto en Markdown, aunque no ejecute skills, no navegue
y no guarde archivos.

## Uso

1. Abre `INICIO_UNIVERSAL.md` y sigue sus siete puntos.
2. Si la herramienta admite abrir carpetas, ábrela entera.
3. Si solo admite adjuntos, adjunta **los cinco archivos** del conjunto mínimo y pega el mensaje de
   activación que aparece allí.

## Demo incluida

`demo/` contiene un centro **ficticio** para probar el sistema sin usar datos reales. No lo mezcles con
documentos de tu centro: si el sistema detecta que está usando la demo en una tarea real, debe avisarlo.

## Capacidades mínimas requeridas

Lectura de Markdown, adjuntos suficientes para el conjunto mínimo y contexto suficiente para la tarea.
**No se promete compatibilidad universal.**

## Comprobación importante

Antes de cerrar cada sesión, pregunta: *«enumera exactamente qué archivos has leído, qué has guardado y
qué has consultado en internet»*. Si afirma algo que la herramienta no puede hacer, la sesión es
inválida: reinicia desde `INICIO_UNIVERSAL.md`.

## Inicio rápido en 4 pasos

1. **Crea o abre un proyecto local** para este sistema aumentado.
2. **Asocia la carpeta extraída** como carpeta de trabajo del proyecto.
3. **Abre una conversación nueva** dentro de ese proyecto.
4. **Escribe tu tarea en lenguaje natural**, por ejemplo: «Prepárame una actividad de 45 minutos para 2.º de ESO sobre energía». No necesitas conocer nombres de skills, agentes ni workflows.

Como comprobación inicial, puedes pedir: «Indica qué sistema eres, qué versión tienes y qué archivos has leído realmente». Después, empieza directamente con una tarea docente.

Cuando ya tengas un resultado, ofrece la configuración mínima del centro. No introduzcas datos reales de menores.

El manual completo en PDF se facilita junto con esta edición desde el repositorio oficial.
Documentación de uso: `documentacion/GUIA_DE_INICIO.md`.
Condiciones comunitarias: `documentacion/CONDICIONES_DE_USO.md`. Descarga sin compra, cupón ni registro en tienda.

## Límites que conviene conocer antes de empezar

Este sistema no pone notas, no clasifica alumnado, no detecta si un texto lo escribió una IA, no
sanciona, no diagnostica y no envía ni publica nada. Ver `documentacion/LIMITES_Y_ESCALADO.md`.

> **Versión 1.3.2-comunitaria.3.** La adaptación comunitaria no extiende automáticamente las confirmaciones
> históricas a estos nuevos ZIP. El paquete de mantenimiento distingue comprobaciones estáticas,
> pruebas históricas y pruebas de plataforma pendientes. Ver `documentacion/EDICION_COMUNITARIA.md`.
