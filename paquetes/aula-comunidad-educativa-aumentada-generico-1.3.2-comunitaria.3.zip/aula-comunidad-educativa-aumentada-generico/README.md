# Aula y Comunidad Educativa Aumentada · Edición Comunitaria

Sistema Aumentado con IA de uso gratuito · versión `1.3.2-comunitaria.3` · Jesús García Fernández.

Lee `README_INSTALACION.md` en la raíz del paquete. En ChatGPT Work, este documento vive en
`aula-comunidad-educativa-aumentada/references/`: la instalación se explica dos niveles por encima.
Una vez montado, empieza por [EMPIEZA_AQUI.md](EMPIEZA_AQUI.md) y pide una tarea en lenguaje natural.

El sistema prepara actividades, explicaciones, feedback, tutorías y borradores para familias.
No pone notas, diagnostica, sanciona ni envía comunicaciones. No introduzcas datos reales de menores.
Las decisiones educativas y profesionales son humanas.

Incluye 22 agentes, 32 workflows, 31 skills, 58 plantillas Markdown numeradas y la matriz Excel.
Cada tarea activa los componentes pertinentes, no todos a la vez.

- [Guía de uso](documentacion/GUIA_MAESTRA_DE_USO.md)
- [Condiciones comunitarias](documentacion/CONDICIONES_DE_USO.md)
- [Agentes](agentes/) y [workflows](workflows/)
- [Skills](skills/) y [plantillas](plantillas/)
- [Cambios y pruebas de esta edición](documentacion/EDICION_COMUNITARIA.md)

El ámbito normativo de referencia es España y su fecha de corte sigue siendo 2026-09-03.
La gratuidad del sistema no incluye las cuentas de las plataformas ni soporte personalizado.
No se garantiza mantenimiento ni compatibilidad permanente.

Las demostraciones completas y las herramientas de reconstrucción están en el repositorio.
El paquete genérico también incluye las demostraciones.

Autor: [Jesús García Fernández](https://jesusgarciafernandez.com/).
