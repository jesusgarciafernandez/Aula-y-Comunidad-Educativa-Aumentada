# Licencia Comunitaria de Uso Profesional

Copyright © 2026 Jesús García Fernández (JGF).

Esta edición se ofrece gratuitamente, con condiciones propias y sin derecho de reventa.
Las condiciones completas y únicas están en
[documentacion/CONDICIONES_DE_USO.md](documentacion/CONDICIONES_DE_USO.md).

Se permite el uso educativo y profesional, la adaptación interna y la prestación de servicios
con resultados revisados. Se contemplan las funciones de copia y fork de GitHub. No se concede
una licencia open source ni un derecho general de redistribución del sistema por otros medios.
Los materiales de terceros conservan sus propias condiciones.
