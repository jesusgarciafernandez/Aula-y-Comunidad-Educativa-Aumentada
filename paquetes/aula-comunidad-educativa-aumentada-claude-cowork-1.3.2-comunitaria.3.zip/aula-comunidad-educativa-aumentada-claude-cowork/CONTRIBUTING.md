# Cómo colaborar

Puedes comunicar un error, una dificultad de instalación o una sugerencia mediante una Issue
del repositorio. Indica versión, plataforma, pasos, resultado esperado y resultado observado.
Usa únicamente ejemplos ficticios: no adjuntes expedientes, trabajos identificables de menores,
datos de familias, credenciales ni documentos internos del centro.

Antes de proponer un cambio, lee las condiciones de uso. Si aportas contenido, debes disponer
de los derechos necesarios y aceptar que tu contribución se integre bajo esas mismas condiciones,
salvo acuerdo expreso distinto. No incorpores materiales protegidos de terceros sin permiso.

Los cambios de contenido se realizan en la fuente; los ZIP se regeneran, no se editan a mano.
Describe el problema que resuelves y las pruebas realizadas. Las propuestas se revisan antes de
integrarse: abrir una Issue o un cambio no garantiza respuesta, aceptación ni plazo de soporte.

Si detectas una posible exposición de datos, no publiques los datos ni el detalle que permita
recuperarlos. Detén el uso y contacta con el responsable del centro y, si procede, con el autor
por los canales de su web profesional.
