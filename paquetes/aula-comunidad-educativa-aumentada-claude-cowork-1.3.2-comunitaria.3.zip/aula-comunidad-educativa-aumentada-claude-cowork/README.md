# Aula y Comunidad Educativa Aumentada · Claude Cowork

Sistema Aumentado con IA de uso gratuito · versión `1.3.2-comunitaria.3` · Jesús García Fernández.

Lee `README_INSTALACION.md` en la raíz del plugin. Después de instalarlo y conectar la carpeta en
**Contexto**, empieza por [EMPIEZA_AQUI.md](EMPIEZA_AQUI.md) y pide una tarea en lenguaje natural.

El sistema prepara actividades, explicaciones, feedback, tutorías y borradores para familias.
No pone notas, diagnostica, sanciona ni envía comunicaciones. No introduzcas datos reales de menores.
Las decisiones educativas y profesionales son humanas.

Incluye 22 subagentes, 32 workflows, 31 skills, 58 plantillas Markdown numeradas y la matriz Excel.
Cada tarea activa los componentes pertinentes, no todos a la vez.

- [Guía de uso](documentacion/GUIA_MAESTRA_DE_USO.md)
- [Condiciones comunitarias](documentacion/CONDICIONES_DE_USO.md)
- [Subagentes](agents/) y [workflows](workflows/)
- [Skills](skills/) y [plantillas](plantillas/)
- [Cambios y pruebas de esta edición](documentacion/EDICION_COMUNITARIA.md)

La gratuidad del sistema no incluye la cuenta de la plataforma ni soporte personalizado.
No se garantiza mantenimiento ni compatibilidad permanente.

Autor: [Jesús García Fernández](https://jesusgarciafernandez.com/).
