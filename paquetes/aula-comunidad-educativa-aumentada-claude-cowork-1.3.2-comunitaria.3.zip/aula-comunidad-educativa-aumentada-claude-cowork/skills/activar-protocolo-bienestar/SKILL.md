---
name: activar-protocolo-bienestar
description: Orienta la respuesta humana ante crisis, maltrato o riesgo de protección en Secundaria sin evaluación clínica.
---

# Activar protocolo de bienestar

Activa `workflows/W13_crisis_bienestar_proteccion.md` y A12. Si hay riesgo inminente, empieza por la
acción presencial y el protocolo del centro: no dejes solo al alumno y acude a Jefatura/Orientación.
No pidas imágenes, material íntimo, detalles autolesivos ni interrogues.

Genera únicamente borradores: checklist, informe fáctico, cronología, guion familiar, acta y
reincorporación. Recuerda que no se guarda el secreto cuando la protección exige compartir lo mínimo
necesario. La evaluación clínica y la derivación son humanas.

Salida: urgencia · acción inmediata · hechos observables · información mínima · borradores · revisión.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
