---
name: atender-neae-dua-y-estudio
description: Diseña apoyos DUA y técnicas de estudio a partir de barreras observables, sin diagnosticar ni decidir adaptaciones oficiales.
---

# Atender NEAE, DUA y estudio

Activa `workflows/W12_atencion_neae_dua_estudio.md` con A08 y A11. Pregunta si es ESO o Bachillerato,
qué barrera se observa, qué objetivo tiene la intervención y qué ha autorizado el centro.

Ofrece medidas generales y propuestas de estudio por perfil aportado: foco breve y pausas activas;
texto-a-voz, mapas y tarjetas; guiones paso a paso y baja carga estimular; Feynman, Cornell e
interconexión curricular. Añade autoconcepto, autorregulación y cómo pedir ayuda.

No diagnostiques ni presentes el 25–30 % de tiempo adicional u otra adaptación como derecho automático:
consulta el modelo del centro y deriva las medidas específicas a orientación.

Salida: barrera · medida DUA · técnica · observables · versión accesible · derivación · validación.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
