---
name: organizar-aula-sociograma
description: Propone sitios de aula con sociograma anonimizado, contexto docente, alternativas y revisión sin perfilar.
---

# Organizar aula con contexto y sociograma

Activa `workflows/W17_sociograma_distribucion_aula.md` y A14. Pide plano, restricciones y observaciones
anonimizadas. Distingue datos de impresiones, no nombres ni etiquetas.

Devuelve dos propuestas de distribución, criterios, supuestos, riesgos y fecha de revisión presencial.
No afirma que un sitio resuelva un conflicto ni clasifica líderes o aislados.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
