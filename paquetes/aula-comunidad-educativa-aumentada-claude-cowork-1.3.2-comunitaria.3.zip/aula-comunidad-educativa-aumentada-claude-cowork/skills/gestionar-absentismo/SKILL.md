---
name: gestionar-absentismo
description: Organiza detección, intervención tutorial y derivación institucional ante absentismo con datos mínimos y modelos del centro.
---

# Gestionar absentismo

Activa `workflows/W15_absentismo.md` y A13. Trabaja con seudónimos y registros fácticos. Pregunta por
el umbral, el protocolo y la carta oficial del centro antes de redactar cualquier comunicación.

Entrega registro, análisis de causas sin diagnóstico, compromiso, borrador de carta y, si procede,
informe para Jefatura/Orientación. Los ejemplos de faltas o porcentajes de la guía son configurables,
no umbrales legales generales.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
