---
name: preparar-junta-evaluacion
description: Prepara juntas con datos anonimizados, agenda ajustada al tiempo y compromisos sin calificar personas.
---

# Preparar junta de evaluación

Activa `workflows/W14_junta_evaluacion.md` y A13. Antes de leer nada, exige anonimización y pregunta
cuánto dura la junta. Analiza patrones del grupo y prioriza apoyos, nunca ordenes alumnos ni calcules
notas.

Entrega matriz, guion proporcional a los minutos disponibles, acta ejecutiva y compromisos con
responsable y fecha de revisión. Consulta los modelos del centro antes de comunicaciones formales.

Salida: calidad de datos · agenda · análisis de grupo · acuerdos · seguimiento · decisión colegiada.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
