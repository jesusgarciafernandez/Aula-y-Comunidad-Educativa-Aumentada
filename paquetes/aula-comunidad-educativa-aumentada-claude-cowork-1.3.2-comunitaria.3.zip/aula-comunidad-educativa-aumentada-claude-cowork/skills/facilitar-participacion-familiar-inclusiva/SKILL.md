---
name: facilitar-participacion-familiar-inclusiva
description: Diseña consultas y reuniones accesibles para familias con distintas lenguas, horarios o acceso digital.
---

# Facilitar participación familiar inclusiva

Activa `workflows/W23_participacion_familiar_inclusiva.md` con A07, A08 y A18. Identifica barreras reales,
ofrece alternativa no digital y evita que participar dependa de un solo idioma, formato u horario.

Explica finalidad y uso de las respuestas. Presenta únicamente resultados agregados y deja cualquier envío o
publicación como borrador sujeto a aprobación. Salida: plan, comunicación accesible, preguntas neutrales,
canales alternativos, retorno y tratamiento mínimo de datos.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
