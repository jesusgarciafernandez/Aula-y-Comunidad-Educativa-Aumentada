---
name: evaluar-herramienta-ia-para-uso-educativo
description: Evalúa una herramienta de IA antes de adoptarla: finalidad, edad, datos, riesgos, accesibilidad y piloto.
---

# Evaluar una herramienta de IA para uso educativo

Ejecuta `workflows/W07_evaluar_herramienta.md`. **Derivación obligatoria a A06 y A10.**

## Cuándo se usa
«¿Podemos usar esta app?», «nos han ofrecido esta herramienta», «esto es gratis para centros, ¿lo
cogemos?».

## Cuándo NO se usa
- Para comprar, crear cuentas o activar pruebas: el sistema no lo hace.
- Para certificar cumplimiento normativo de un proveedor: el sistema no lo certifica.

## Entradas
Nombre de la herramienta y uso previsto.

## Pasos
0. **Filtro de práctica prohibida.** ¿Hace reconocimiento o inferencia de emociones, categorización
   biométrica, reconocimiento facial, vigilancia de exámenes o generación de contenido íntimo? Si sí,
   la evaluación termina: se muestra la referencia RN-01 con enlace y fecha, se formula la implicación
   en condicional y se remite al DPD y a la asesoría. No se dictamina.
1. Finalidad educativa. Si no hay problema claro que resolver, se para aquí.
2. Destinatarios y edad, frente a las condiciones de edad de la herramienta.
3. Datos: qué pide, dónde se almacenan, si se usan para entrenar, quién responde.
4. Condiciones, tipo de cuenta y coste real.
5. Función pedagógica frente a lo que ya existe, y alternativas (incluida no adoptar nada).
6. Riesgos: dependencia, continuidad, contenido inadecuado, sesgos, exposición de menores.
7. Accesibilidad.
8. Diseño del piloto: grupo pequeño, tiempo acotado, criterios de éxito y de parada.

## Contrato de salida
Ficha completa según `plantillas/12_ficha_evaluacion_herramienta.md`, con los huecos convertidos en
preguntas expresas al proveedor y con la decisión reservada al órgano competente.

## Regla
Una ficha con huecos críticos **no** justifica una adopción.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
