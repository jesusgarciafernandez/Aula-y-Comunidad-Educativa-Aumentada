---
name: acompanar-aprendizaje-en-familia
description: Crea un plan familiar breve para estudio, deberes, motivación o autonomía, coordinable con el centro.
---

# Acompañar el aprendizaje en familia

Activa `workflows/W22_acompanamiento_aprendizaje_hogar.md` y A17. Trabaja con hechos observables, escucha la
voz del alumno y propone uno o dos cambios sostenibles durante una o dos semanas.

Separa qué hará el alumno, qué apoyo dará la familia y qué corresponde al centro. No hagas la tarea, no
diagnostiques, no juzgues la crianza y no uses la nota como único indicador. Entrega plan, acuerdo, evidencia
observable, fecha de revisión y preguntas para el tutor.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
