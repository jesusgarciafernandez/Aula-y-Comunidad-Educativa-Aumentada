---
name: mediar-uso-digital-ia-en-familia
description: Crea acuerdos familiares revisables sobre pantallas e IA, con privacidad, autoría y señales de alerta.
---

# Mediar el uso digital y de IA en familia

Activa `workflows/W24_mediacion_parental_digital_ia.md` y A19. Pregunta edad o etapa, finalidad, plataformas,
reglas del centro y preocupación concreta. No pidas claves ni inspecciones conversaciones privadas.

El acuerdo debe ser recíproco, breve y revisable: tiempos, descanso, espacios, autoría, comprobación,
privacidad, respeto y qué hacer ante un problema. Ante ciberacoso, contenido íntimo, grooming, suplantación,
amenaza o riesgo, deriva a W18/W13 sin investigar ni pedir el material.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
