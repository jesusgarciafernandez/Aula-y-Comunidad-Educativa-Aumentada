---
name: crear-normas-uso-responsable-ia
description: Prepara o revisa el borrador participativo de normas de uso de IA de un centro o entidad educativa.
---

# Crear o revisar normas de uso responsable de la IA

Ejecuta `workflows/W06_normas_uso_responsable.md`. **Derivación obligatoria a A06 y A10.**

## Cuándo se usa
«Necesitamos una política de IA», «hay que poner normas claras», «cada docente hace una cosa
distinta», «las familias preguntan qué está permitido».

## Cuándo NO se usa
- Para comunicar una norma ya aprobada → `preparar-comunicacion-familias-comunidad`.
- Para decidir sobre una herramienta concreta → `evaluar-herramienta-ia-para-uso-educativo`.
- Para obtener un dictamen jurídico: el sistema no lo emite en ningún caso.

## Entradas
Tipo de entidad, etapas y quién aprueba. Opcional: normas de convivencia, plan digital, protocolo de
datos existentes.

## Pasos
1. Revisa qué existe ya y no lo contradigas sin decirlo.
2. Diseña cómo se recoge la voz de docentes, familias, alumnado y personal.
3. Mapa de **usos reales** (lo que se hace, no lo que debería hacerse).
4. Clasifica cada uso: **permitido / condicionado / no permitido**, siempre con el porqué.
5. Transparencia, privacidad, autoría y evaluación.
6. Procedimiento de incidentes.
7. Versiones de comunicación por público.
8. Aprobación institucional y calendario de revisión.

## Contrato de salida
Ámbito · finalidad · actores · usos permitidos, condicionados y no permitidos · datos · transparencia ·
autoría · evaluación · supervisión · incidentes · participación · comunicación · revisión · aprobación
requerida · límites jurídicos. Sale marcado como **Propuesta**.
Plantillas: `plantillas/09_matriz_usos.md` y `plantillas/10_politica_de_centro.md`.

## Límite
El sistema distingue obligación legal, orientación y acuerdo interno, y **no determina** qué obligación
concreta recae sobre la entidad.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
