---
name: inicio-curso-comunidad-educativa
description: Apoya el inicio de curso, el primer día, las reuniones con familias y la acogida en Secundaria.
---

# Skill · Inicio de curso y comunidad educativa

## Cuándo activarlo

Activa esta skill cuando la persona pida ayuda para comenzar el curso académico, organizar el primer
día con el alumnado, preparar la primera reunión de un docente con las familias, diseñar la reunión
general del instituto con las familias o acompañar a padres, madres y tutores legales durante las
primeras semanas.

## Preguntas mínimas antes de proponer

Pregunta, o marca como **No consta**, lo que no esté disponible:

- rol de quien solicita y público destinatario;
- etapa, curso, tamaño aproximado y necesidades de apoyo relevantes;
- hito concreto, fecha, duración, asistentes y espacio o canal;
- idioma, accesibilidad, conectividad y alternativa no digital;
- materiales, recursos y decisiones ya aprobadas por el centro;
- preocupación principal y qué debe quedar revisable.

No entregues una agenda genérica si faltan datos que cambien el diseño. Si se trata de una situación
individual o sensible, separa la orientación general y deriva a la revisión humana del centro.

## Rutas de trabajo

| Necesidad | Workflow | Resultado |
|---|---|---|
| Organizar el inicio de curso desde dirección | W28 | Plan por hitos, responsables, recursos y revisión |
| Preparar el primer día con alumnos | W29 | Guion flexible de acogida, orientación y ayuda |
| Preparar la primera reunión docente-familia | W30 | Agenda de escucha, voz del alumno y acuerdos |
| Preparar la reunión general del instituto | W31 | Mensajes comunes, canales, accesibilidad y preguntas |
| Apoyar a las familias al iniciar el curso | W32 | Kit breve, primer paso, ayuda y revisión |

## Regla de adaptación y comprensión

Cada técnica, guion o recurso debe decir para quién es, qué problema práctico resuelve y por qué encaja
con el contexto aportado. Ofrece una versión breve, clara y accesible y, cuando sea posible, una
alternativa oral o en papel. Incluye una comprobación sencilla de comprensión: localizar un canal,
repetir tres mensajes, explicar el primer paso, elegir una alternativa o indicar dónde pedir ayuda.
Pregunta si el formato, el ritmo y la cantidad de información resultan utilizables; si no, ajusta la
salida antes de añadir más contenido.

## Formato de salida

Entrega una propuesta marcada como **Sugerencia operativa a revisar y contrastar**, con:

1. contexto confirmado y **No consta**;
2. público, objetivo, duración y materiales;
3. secuencia o guion adaptable;
4. responsabilidades, canal y alternativa accesible;
5. comprobación de comprensión y ajuste previsto;
6. riesgos, privacidad, huecos y persona u órgano que debe aprobar;
7. siguiente pregunta para que el usuario elija el primer paso.

## Límites

No envíes convocatorias ni mensajes, no publiques calendarios, no matricules, no asignes apoyos, no
diagnostiques, no evalúes familias o alumnos y no confirmes becas, transporte, horarios o cumplimiento
normativo sin fuente y validación competente. La reunión general no contiene expedientes ni casos
individuales. La primera reunión docente-familia no sustituye tutoría, orientación ni protocolos de
protección. Ante una señal de riesgo, detén la propuesta operativa y activa el protocolo humano del
centro.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
