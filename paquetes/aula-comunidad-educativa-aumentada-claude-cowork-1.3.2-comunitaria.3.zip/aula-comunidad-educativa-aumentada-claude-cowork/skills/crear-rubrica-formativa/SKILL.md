---
name: crear-rubrica-formativa
description: Crea una rúbrica analítica o lista de cotejo con criterios observables, niveles y descriptores en lenguaje del alumnado.
---

# Crear una rúbrica formativa

## Cuándo se usa
«Necesito una rúbrica», «cómo evalúo esto», «qué criterios pongo», o automáticamente antes de
`revisar-trabajo-con-feedback` cuando no existen criterios.

## Cuándo NO se usa
- Para calcular notas, ponderaciones o medias: el sistema no califica.
- Para evaluar personas: se evalúan producciones.

## Entradas
Tarea o producción, etapa, resultado de aprendizaje. Opcional: criterios que ya use el centro.

## Pasos
1. Parte del **resultado de aprendizaje**, no del contenido.
2. Selecciona entre 3 y 5 criterios. Más criterios no es más rigor: es más ruido.
3. Escribe cada criterio como algo **observable en la producción**.
4. Define 3 o 4 niveles con descriptores concretos, sin adjetivos vacíos («bueno», «adecuado»).
5. Escribe la versión **en lenguaje del alumnado**, para que sepa qué se espera antes de empezar.
6. Añade una lista de cotejo breve para autorrevisión.
7. Declara qué **no** mide esta rúbrica.

## Contrato de salida
Rúbrica analítica (criterios × niveles con descriptores) + lista de cotejo para el alumnado + qué no
mide + decisión docente pendiente. Plantilla: `plantillas/05_rubrica_y_lista_cotejo.md`.

## Límites
Sin puntuaciones, sin pesos, sin conversión a nota. Sin criterios sobre la persona (actitud, esfuerzo
percibido, madurez).


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
