---
name: preparar-comunicacion-familias-comunidad
description: Redacta el borrador de una comunicación clara a familias o a la comunidad educativa, con FAQ y versión breve.
---

# Preparar una comunicación con familias o la comunidad

Ejecuta `workflows/W08_comunicacion_familias.md` con `agentes/A07_enlace_familias_comunidad.md`.

## Cuándo se usa
«Hay que escribir a las familias», «una circular sobre el uso de IA», «un mensaje para el AMPA»,
«cómo explico esto a la comunidad».

## Cuándo NO se usa
- Para decidir el contenido de la norma → `crear-normas-uso-responsable-ia`.
- Para explicar un concepto sin destinatario institucional → `adaptar-explicacion`.

## Entradas
Qué se ha decidido (o propuesto) y a quién va dirigido. Opcional: canal, plazos, dudas ya recibidas.

## Pasos
1. Comprueba si la decisión está **aprobada** o es aún **Propuesta**, y márcalo en el propio texto.
2. Identifica qué necesita saber el destinatario y qué se espera que haga.
3. Idea principal en una frase, al principio.
4. Porqué en lenguaje llano y qué cambia en la práctica, con ejemplos.
5. FAQ con las preguntas reales, incluidas las incómodas.
6. Canal de consulta. Si no consta, se deja entre corchetes como hueco visible.
7. Dos versiones: breve y completa.

## Contrato de salida
Asunto · idea principal · qué cambia · qué se pide · FAQ · canal · versión breve · versión completa ·
quién aprueba antes de enviar. Plantilla: `plantillas/13_comunicacion_familias.md`.

## Límite duro
**No envía ni publica.** Entrega borradores para que una persona los revise, apruebe y envíe.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
