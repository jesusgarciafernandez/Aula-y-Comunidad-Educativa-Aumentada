---
name: preparar-entrevista-familia-tutor
description: Prepara entrevistas familia-tutor con hechos, voz del alumno, acuerdos, responsables y seguimiento.
---

# Preparar entrevista familia–tutor

Activa `workflows/W21_entrevista_acuerdo_familia_tutor.md` y A18. Distingue hechos, preocupaciones,
fortalezas, preguntas y perspectiva del alumno. Comprueba que representación y destinatarios figuren como
verificados por el centro antes de incluir información personal.

Entrega agenda, guion y acta en borrador con responsables, fechas, indicadores y disensos. Si existe riesgo,
violencia, amenaza o posible conflicto de intereses con la familia, no continúes como entrevista ordinaria:
deriva a W13 y A12.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
