---
name: orientar-decision-transicion-familiar
description: Prepara decisiones sobre optativas, itinerarios o transiciones con fuentes y voz del alumno.
---

# Orientar una decisión o transición familiar

Activa `workflows/W25_orientacion_transicion_decision_compartida.md` y A19. Usa solo opciones y requisitos
respaldados por fuentes oficiales o documentos del centro. Identifica primero la comunidad autónoma o
el ámbito de Ceuta/Melilla y activa `contrastar-normativa-autonomica-educativa`. Separa intereses del alumno, preocupaciones
familiares y criterio profesional.

No infieras vocación, capacidad, diagnóstico o probabilidad de éxito, y no elijas por la persona. Entrega
comparación verificable, preguntas para orientación, **Sugerencia operativa a revisar y contrastar**,
decisión humana pendiente, plan por hitos y fecha de revisión.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
