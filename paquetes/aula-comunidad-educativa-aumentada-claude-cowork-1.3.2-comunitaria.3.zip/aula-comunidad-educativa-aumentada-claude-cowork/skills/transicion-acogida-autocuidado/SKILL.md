---
name: transicion-acogida-autocuidado
description: Prepara planes de tránsito, acogida, tutorías, entrevistas familiares, límites comunicativos y autocuidado docente en Secundaria.
---

# Transición, acogida y autocuidado

Activa `workflows/W19_transicion_acogida_entrevistas.md` y A16. Pregunta etapa, momento del curso,
objetivo, idioma, canal y recursos del centro.

Diseña hitos para 15 días de tránsito, compañero mentor y revisión; guiones individuales y familiares;
límites de horario/canal y descompresión entre pares. Si una familia pierde el control, prioriza la
seguridad y deriva al canal institucional.

Salida: plan · guion · límites · apoyos · riesgos · revisión · aprobación del centro.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
