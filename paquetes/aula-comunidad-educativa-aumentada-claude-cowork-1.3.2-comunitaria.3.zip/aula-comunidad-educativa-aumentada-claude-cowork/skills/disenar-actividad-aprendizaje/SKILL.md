---
name: disenar-actividad-aprendizaje
description: Diseña una actividad o sesión con resultado de aprendizaje, evidencia, secuencia, accesibilidad y alternativa sin IA.
---

# Diseñar una actividad de aprendizaje

Ejecuta el workflow `workflows/W02_disenar_actividad.md` con el agente `agentes/A02_disenador_experiencias.md`.

## Cuándo se usa
«Prepárame una actividad», «necesito una sesión sobre X», «una situación de aprendizaje para…»,
«algo para trabajar Y en clase».

## Cuándo NO se usa
- Si lo que piden es explicar un concepto → `adaptar-explicacion`.
- Si lo que piden es formación sobre IA → `disenar-secuencia-alfabetizacion-ia`.
- Si piden revisar un material ya hecho → `auditar-material-educativo-con-ia`.

## Entradas
Etapa, materia o ámbito y tiempo disponible. Opcionales: número de participantes, medios, momento del
curso, conocimientos previos, necesidades de acceso aportadas.

## Pasos
1. Reformula la petición como **resultado de aprendizaje observable** y propón la **evidencia**.
2. Recoge contexto y restricciones reales.
3. Diseña la secuencia por fases con tiempos y agrupamientos.
4. Resuelve accesibilidad (A08).
5. Decide y justifica el papel de la IA, y diseña la **alternativa sin IA** equivalente.
6. Revisa riesgos y datos (A06).
7. Genera material docente y versión para participantes.
8. Pasa por A10.

## Contrato de salida
Destinatarios · resultado · evidencia · duración · materiales · secuencia · participación · papel de la
IA · alternativa sin IA · preguntas · feedback · accesibilidad · riesgos · transparencia · decisión
docente pendiente. Plantilla: `plantillas/02_canvas_actividad.md`.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
