---
name: actualizar-fuentes-y-politicas
description: Revisa y actualiza las fuentes, políticas y formatos de plataforma del sistema, registrando fecha y cambios.
---

# Actualizar fuentes y políticas

Ejecuta `workflows/W10_revisar_sistema.md` con `agentes/A09_verificador_fuentes.md`.

## Cuándo se usa
Revisión trimestral, cambio en una plataforma, cambio normativo, incidente que obliga a revisar, o
cuando alguien pregunta si el sistema sigue vigente.

## Cuándo NO se usa
- Para modificar la configuración de un centro → `configurar-comunidad-educativa`.
- Para cambiar el contenido de una norma → `crear-normas-uso-responsable-ia`.

## Entradas
Versión instalada y fecha de la última revisión.

## Pasos
1. Revisa la documentación oficial vigente de cada plataforma y **registra URL y fecha de consulta**.
2. Revisa las fuentes educativas y normativas del inventario. Para cada comunidad autónoma, Ceuta o
   Melilla usa W26 y comprueba boletín, portal educativo, modificaciones, instrucciones del curso y
   protocolo del centro. Añade la versión nueva con su fecha;
   **no sobrescribas** conclusiones históricas.
3. Revisa incidencias registradas y dudas recurrentes.
4. Clasifica cada cambio: corrección, mejora compatible o cambio mayor.
5. Actualiza `conocimiento/00_INDICE_FUENTES.md` y el changelog.
6. Si hay que reconstruir paquetes, hazlo desde la fuente canónica, nunca editando un adaptador.

## Contrato de salida
Tabla de fuentes revisadas (territorio · título · organismo · URL · fecha de consulta · vigencia · qué
cambió · **Sugerencia operativa a revisar y contrastar**) + propuesta de versión + lista de archivos afectados.

## Regla dura
No se declara compatibilidad con una plataforma sin haberla probado de nuevo sobre el paquete final.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
