---
name: disenar-secuencia-alfabetizacion-ia
description: Diseña una secuencia de alfabetización en IA para docentes, familias, alumnado o entidades, con práctica y evidencia.
---

# Diseñar una secuencia de alfabetización en IA

Ejecuta `workflows/W05_alfabetizacion_ia.md` con `agentes/A05_facilitador_alfabetizacion.md`.

## Cuándo se usa
«Formación sobre IA para el claustro», «un taller para familias», «que el alumnado aprenda a usarla
con criterio», «una sesión sobre alucinaciones y comprobación».

## Cuándo NO se usa
- Para una actividad de aula sobre otro tema → `disenar-actividad-aprendizaje`.
- Para explicar un concepto suelto → `adaptar-explicacion`.
- Para redactar normas → `crear-normas-uso-responsable-ia`.

## Entradas
Público y tiempo disponible. Opcional: usos actuales, preocupaciones, contexto real de trabajo.

## Pasos
1. Diagnóstico **no invasivo**: usos y dudas, nunca test individual de nivel.
2. Objetivo competencial en la progresión: comprender → comprobar → decidir → integrar → acompañar.
3. Experiencia práctica sobre una tarea real del contexto.
4. **Contraste**: comparar la salida de la IA con una fuente, con el criterio profesional o con el
   resultado sin IA. Este paso no es opcional.
5. Ética, datos y sesgos con casos propios.
6. Reflexión breve y no expuesta públicamente.
7. Evidencia de aprendizaje observable.
8. Transferencia: una tarea real para la semana siguiente.

## Contrato de salida
Público · punto de partida · objetivo competencial · actividades con tiempos · materiales · evidencia ·
reflexión · transferencia · riesgos · decisión humana pendiente.

## Límites
No certifica niveles de ningún marco oficial. No evalúa individualmente a docentes ni a familias.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
