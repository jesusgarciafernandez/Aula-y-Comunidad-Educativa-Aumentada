---
name: configurar-comunidad-educativa
description: Configura el sistema para un centro, AMPA o entidad educativa: contexto, modos, datos, herramientas y responsables.
---

# Configurar la comunidad educativa

Ejecuta el workflow `workflows/W01_configuracion_inicial.md`.

## Cuándo se usa
Primera sesión con una entidad, inicio de curso, cambio de responsable, o cuando la persona dice que
quiere «empezar», «poner esto en marcha» o «adaptarlo a mi centro».

## Cuándo NO se usa
- Cuando ya existe configuración y solo hay que cambiar un dato: edita `00_CONFIGURACION_COMUNIDAD_EDUCATIVA.md` directamente.
- Cuando la persona solo quiere una tarea concreta: hazla con la configuración mínima y ofrece configurar después.

## Entradas
Tipo de entidad, etapas, rol de la persona, idioma, herramientas de IA permitidas. Nada más es obligatorio.

## Pasos
1. Configuración mínima por conversación: cinco preguntas, máximo diez minutos.
2. Índice de fuentes: qué documentos hay y cuáles no (`conocimiento/00_INDICE_FUENTES.md`).
3. Modos y responsables. El modo alumnado acompañado solo se activa con autorización nominal.
4. Reglas de datos y anonimización (A06).
5. Transparencia, evaluación y accesibilidad.
6. Calendario de revisión y lista de huecos con responsable.

## Contrato de salida
Ficha `00_CONFIGURACION_COMUNIDAD_EDUCATIVA.md` rellenada, índice de fuentes inicializado y tabla de
huecos («No consta») con responsable y fecha. Nunca rellenar huecos por suposición.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
