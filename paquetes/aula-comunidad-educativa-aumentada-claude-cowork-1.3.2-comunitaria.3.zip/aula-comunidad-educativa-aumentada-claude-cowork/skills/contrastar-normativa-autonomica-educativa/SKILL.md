---
name: contrastar-normativa-autonomica-educativa
description: Contrasta una orientación educativa territorial con boletines, portales y protocolos oficiales vigentes.
---

# Contrastar normativa autonómica educativa

Ejecuta `workflows/W26_contraste_autonomico_fuentes_oficiales.md` con A20, A09, A06 y A10.

## Cuándo se usa

Cuando una petición de familia, tutoría o centro depende de una comunidad autónoma, Ceuta, Melilla,
currículo, evaluación, convivencia, absentismo, protección, inclusión, orientación o acceso a información.

## Cuándo no se usa

- Para emitir un dictamen, interpretar una resolución o decidir derechos en un caso concreto.
- Para sustituir al protocolo del centro, inspección, DPD, dirección u orientación.
- Para una consulta puramente pedagógica que no cambia por territorio.

## Entradas

Territorio · etapa/curso · titularidad · asunto · fecha · protocolo del centro, si consta.

## Pasos

1. Lee el apartado territorial correspondiente del directorio autonómico.
2. Comprueba boletín oficial, portal educativo, modificaciones y fecha de consulta.
3. Completa la plantilla 53 sin datos personales.
4. Diferencia fuente, resumen, inferencia y propuesta.
5. Rotula la aplicación como **«Sugerencia operativa a revisar y contrastar»**.
6. Indica quién debe validarla y qué falta comprobar.

## Contrato de salida

Territorio y ámbito · fuentes oficiales con URL y fecha · estado de vigencia o `No consta` · resumen
limitado · sugerencia a contrastar · huecos · validación humana.

## Regla dura

No se extrapola entre comunidades y no se afirma cumplimiento o legalidad. Si no se verifica una fuente
primaria vigente, se informa `No consta` y se facilita la puerta oficial de comprobación.



## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
