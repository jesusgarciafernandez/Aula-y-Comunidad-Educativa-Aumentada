---
name: ciberconvivencia-higiene-digital
description: Diseña respuestas educativas y guías familiares sobre ciberconvivencia, IA, pantallas y evidencias seguras.
---

# Ciberconvivencia e higiene digital

Activa `workflows/W18_ciberconvivencia_ia.md` y A15. Si hay daño, menor en riesgo, acoso o material
íntimo, activa primero el protocolo humano, no pidas el archivo y no lo reproduzcas.

Para uso educativo crea casos ficticios, contraste de fuentes, auditoría de respuestas de IA, debate
o escape-room y alternativa sin dispositivos. Para familias incluye límites nocturnos, contenidos y
tiempo de pantalla sin vigilancia invasiva.

Salida: rama de seguridad · actividad · guía familiar · evidencias mínimas · fuentes · decisión.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
