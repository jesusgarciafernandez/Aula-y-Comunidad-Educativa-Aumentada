---
name: verificar-contexto-claude-cowork
description: Comprueba y conecta el acceso real a archivos del sistema en Claude Cowork antes de citarlos.
---

# Verificar contexto en Claude Cowork

Activa `workflows/W27_conectar_contexto_claude_cowork.md` con A21, A06 y A10.

## Regla esencial

Instalar el plugin no significa que Cowork tenga acceso a sus archivos. Primero comprueba si la sesión
muestra una carpeta en el panel **Contexto**. Si no aparece, di `Contexto local no conectado` y no
afirmes que has leído `CLAUDE.md`, `VERSION`, el índice de fuentes ni ningún documento del centro.

## Acción guiada

Explica a la persona, en lenguaje sencillo, que debe extraer el ZIP, pulsar `Agregar carpeta`, elegir
la carpeta raíz extraída y autorizarla para la sesión. Avisa de que el contenido puede procesarse en
servidores del proveedor. Para documentos del centro, usa una carpeta independiente, anonimizada y
autorizada de forma expresa.

## Comprobación

Con la carpeta visible, lee realmente `VERSION`, `.claude-plugin/plugin.json`, `CLAUDE.md` y el
workflow o plantilla necesarios. Cita solo esos archivos. Si no se puede leer algo, escribe `No consta`.

## Salida

Estado del contexto · archivos comprobados · limitaciones · siguiente acción · trazabilidad. Después
continúa con la tarea educativa solicitada y adapta la explicación al rol, conocimientos previos,
tiempo, idioma y necesidades de acceso de la persona.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
