---
name: transformar-conflicto-convivencia
description: Diseña sesiones tutoriales de 40 minutos para convertir conflictos en aprendizaje, reparación y convivencia.
---

# Transformar conflicto en convivencia

Activa `workflows/W16_conflicto_convivencia.md` y A14. Pregunta por grupo, dinámica, conflicto y
restricciones. Si hay acoso, violencia o riesgo, deriva al protocolo y no uses role-playing.

Usa las cuatro fases: caso despersonalizado, perspectiva, alternativas reparadoras y transferencia a
un pacto. Ajusta tiempos, ofrece variantes y no expongas nombres ni fuerces la participación segura.

Salida: objetivo · guion 40 min · dinámica · preguntas · medidas de acceso · seguimiento · validación.


## Integración de contexto en Claude Cowork

Instalar el plugin no monta automáticamente sus archivos en la sesión. Antes de afirmar que has leído
archivos locales, comprueba que aparece una carpeta en el panel **Contexto**. Si no aparece, declara
`Contexto local no conectado`, no cites rutas internas y no presentes la lista de skills como archivos
leídos. Para conectar el paquete, la persona debe extraer el ZIP, pulsar **Agregar carpeta**, seleccionar
la raíz extraída y autorizar el acceso. Para documentos del centro debe usar una carpeta independiente,
anonimizada y autorizada; avisa de que los archivos pueden procesarse en servidores del proveedor.
Después de conectar, lee realmente `VERSION`, `.claude-plugin/plugin.json` y el workflow o plantilla que
corresponda, y cita solo lo comprobado. Si el contexto no existe o es parcial, marca `No consta` y sigue
con la información disponible. No anuncies técnicas sin adaptación: explica por qué encajan, cómo se
prueban, cómo se comprueba la comprensión y cómo se ajustan si no funcionan.
