# Instalación · Aula y Comunidad Educativa Aumentada · Edición Comunitaria

**Paquete:** Claude Cowork · **Versión:** `1.3.2-comunitaria.3`

## Qué contiene

- `.claude-plugin/plugin.json` — manifiesto del plugin.
- `skills/` — las treinta y una skills, cada una con su `SKILL.md`.
- `agents/` — los veintidós agentes especializados.
- Núcleo, workflows, plantillas, conocimiento, documentación y resultados en la raíz.

Las carpetas van en la **raíz del plugin**, nunca dentro de `.claude-plugin/`.

## Instalación del plugin

1. Extrae este ZIP en una carpeta estable (no en Descargas).
2. Instala el plugin desde el gestor de plugins de Cowork, apuntando a la carpeta extraída.
   El procedimiento documentado equivalente en línea de comandos es
   `claude --plugin-dir <ruta>` (acepta también el propio `.zip`), y
   `claude plugin validate <ruta>` para comprobarlo.
3. Si el gestor pide recargar, hazlo.
4. Escribe en lenguaje natural: *«necesitamos unas normas de uso de IA en el centro»*. No hace falta
   ningún comando: el arranque por lenguaje natural es el modo previsto.

## Conectar el contexto de archivos — paso imprescindible para el conocimiento completo

Instalar el plugin no conecta automáticamente sus archivos a una sesión Cowork.

1. Abre una sesión nueva en modo Cowork.
2. En el compositor o en el panel de actividad, pulsa **Agregar carpeta**.
3. Selecciona la carpeta raíz extraída del plugin, no el ZIP ni una subcarpeta aislada.
4. Lee el aviso y pulsa **Allow/Permitir** solo si la política del centro autoriza que esos archivos
   se procesen en la infraestructura del proveedor.
5. Comprueba que la carpeta aparece en **Contexto**.
6. Pide: *«comprueba que puedes leer `VERSION`, `.claude-plugin/plugin.json` y `CLAUDE.md`; enumera
   únicamente archivos realmente leídos»*.

Si **Contexto** está vacío, la sesión puede usar la skill activa, pero debe decir `Contexto local no
conectado`, no citar archivos internos y marcar como `No consta` lo que dependa del paquete. No hay una
instrucción dentro del plugin que pueda activar este permiso por sí misma.

## Dónde poner el contexto de tu comunidad

**Separado del método.** Añade como segunda carpeta de contexto una carpeta propia para tu centro; el
plugin aporta el método y tú aportas los documentos. Usa `conocimiento/` siguiendo el `_LEEME.md` de cada
subcarpeta y registra todo en `conocimiento/00_INDICE_FUENTES.md`. No mezcles datos reales de menores con
`demo/`, pruebas ni el ZIP distribuible.

Procedimiento ampliado: `documentacion/INTEGRACION_CLAUDE_COWORK.md` y skill
`verificar-contexto-claude-cowork`.

## Permisos

Este plugin **no** declara conectores, hooks, servidores MCP ni ejecución externa. No los necesita y no
debes añadirlos para usarlo.

> Instalación y funcionamiento confirmados por el titular el 3 de septiembre de 2026.

## Inicio rápido en 4 pasos

1. **Crea o abre un proyecto local** para este sistema aumentado.
2. **Asocia la carpeta extraída** como carpeta de trabajo del proyecto.
3. **Abre una conversación nueva** dentro de ese proyecto.
4. **Escribe tu tarea en lenguaje natural**, por ejemplo: «Prepárame una actividad de 45 minutos para 2.º de ESO sobre energía». No necesitas conocer nombres de skills, agentes ni workflows.

Como comprobación inicial, puedes pedir: «Indica qué sistema eres, qué versión tienes y qué archivos has leído realmente». Después, empieza directamente con una tarea docente.

Cuando ya tengas un resultado, ofrece la configuración mínima del centro. No introduzcas datos reales de menores.

El manual completo en PDF se facilita junto con esta edición desde el repositorio oficial.
Documentación de uso: `documentacion/GUIA_DE_INICIO.md`.
Condiciones comunitarias: `documentacion/CONDICIONES_DE_USO.md`. Descarga sin compra, cupón ni registro en tienda.

## Límites que conviene conocer antes de empezar

Este sistema no pone notas, no clasifica alumnado, no detecta si un texto lo escribió una IA, no
sanciona, no diagnostica y no envía ni publica nada. Ver `documentacion/LIMITES_Y_ESCALADO.md`.

> **Versión 1.3.2-comunitaria.3.** La adaptación comunitaria no extiende automáticamente las confirmaciones
> históricas a estos nuevos ZIP. El paquete de mantenimiento distingue comprobaciones estáticas,
> pruebas históricas y pruebas de plataforma pendientes. Ver `documentacion/EDICION_COMUNITARIA.md`.
